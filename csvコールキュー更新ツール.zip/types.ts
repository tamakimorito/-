
export interface CsvRow {
  [key: string]: string;
}
